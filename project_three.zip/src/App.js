import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import RootRoute from "./Routing/RootRoute";

function App() {
  return (
    <div className="App">
      <RootRoute />
    </div>
  );
}

export default App;
