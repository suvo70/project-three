import React, { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import "./Registration.css";
import axios from "axios";

const Registration = () => {
  const validateEmail = RegExp("^([a-z0-9.-]+)@([a-z]{5,12}).([a-z.]{2,20})$");
  const validatePassword = RegExp(
    "^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{4,12}$"
  );
  const [inputState, setInputState] = useState({
    isError: {
      username: "",
      email: "",
      password: "",
    },
  });

  const handleChange = (event) => {
    event.persist();
    //console.log("Handlechange: ", event);
    let { name, value } = event.target;
    let isErr = { ...inputState.isError };
    switch (name) {
      case "username":
        isErr.username =
          value.length < 4 ? "Atleast 4 characters required" : "";
        break;
      case "email":
        //isErr.email = value.length < 4 ? "Atleast 4 characters required" : "";
        isErr.email = validateEmail.test(value) ? "" : "Wrong Pattern";
        break;
      case "password":
        isErr.password =
          // value.length < 4 ? "Atleast 4 characters required" : "";
          validatePassword.test(value) ? "" : "Wrong Pattern";
        break;
      default:
        break;
    }
    setInputState({ ...inputState, [name]: value, isError: isErr });
    console.log(inputState);

    // part 4
    // setInputState({ ...inputState, [name]: value });
    // console.log("Input State: ", inputState);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    console.log("After submit: ", inputState);
    const user = inputState;

    axios
      .post("https://project-node-1.herokuapp.com/postUserData", user)

      .then((res) => {
        console.log("axios resposce: ", res);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div className="font_style">
      <h1>Registration page</h1>
      <form onSubmit={submitHandler}>
        <Container>
          <Row>
            <Col>
              <label className="label_style"> name</label>
              <input
                type="text"
                placeholder="username"
                name="username"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.username.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.username}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              {" "}
              <label className="label_style email">Email Id</label>
              <input
                type="email"
                placeholder="abc@email.com"
                name="email"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.email.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.email}
                </span>
              )}
            </Col>
            <Col>
              {" "}
              <label className="label_style pass">Password</label>
              <input
                type="password"
                placeholder="password"
                name="password"
                onChange={handleChange}
                className="input_style"
              ></input>
              {inputState.isError.password.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.password}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              <button variant="promary" type="submit" className="btn_style">
                Submit
              </button>
            </Col>
          </Row>
        </Container>
      </form>
    </div>
  );
};

export default Registration;
