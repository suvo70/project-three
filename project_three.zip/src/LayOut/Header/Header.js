import React from "react";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import { Navbar, Container, NavDropdown, Nav, Button } from "react-bootstrap";

const Header = () => {
  const history = useHistory();
  function logOut() {
    window.sessionStorage.clear();
    history.push("/Rgistration_page");
  }
  return (
    <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
      <Container>
        <Navbar.Brand as={Link} to="/home_page">
          Shopping Express
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to={"/home_page"}>
              Home
            </Nav.Link>
            <Nav.Link as={Link} to={"/about_page"}>
              About
            </Nav.Link>
            <NavDropdown title="Product" id="collasible-nav-dropdown">
              <NavDropdown.Item as={Link} to={"/ProductCategory_page"}>
                Category
              </NavDropdown.Item>
              <NavDropdown.Item as={Link} to={"/Rgistration_page"}>
                Register yourself
              </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4">
                Separated link
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
          <Nav>
            <Nav.Link as={Link} to={"/login_page"}>
              Log in / sign up
            </Nav.Link>
            <Button onClick={logOut}>Log out</Button>
            <Nav.Link as={Link} to={"/login_page"}>
              ❤️
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
