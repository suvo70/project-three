import React from "react";
import { Route, Switch, BrowserRouter as Router } from "react-router-dom";
import Login from "../Authorization/Login/Login";
import Registration from "../Authorization/Registration/Registration";
import About from "../Components/About/About";
import Home from "../Components/Home/Home";
import Header from "../LayOut/Header/Header";
import Protected from "./Protected";
import ProductCategory from "../Products/ProductCategory/ProductCategory";

const RootRoute = () => {
  return (
    <div>
      <Router>
        <Header />
        <Switch>
          <Route path="/home_page" component={Home} />
          <Route path="/about_page" component={About} />
          <Route path="/Rgistration_page" component={Registration} />
          <Route path="/login_page" component={Login} />
          <Protected path="/ProductCategory_page" component={ProductCategory} />
          <Route
            render={() => {
              <h1>404: Page not Found!!!!</h1>;
            }}
          />
        </Switch>
      </Router>
    </div>
  );
};

export default RootRoute;
