import React from "react";
import { Redirect } from "react-router";

const Protected = (props) => {
  let Protected = props.component;
  let isLoggedin = window.sessionStorage.getItem("Token: ");
  return isLoggedin ? <Protected /> : <Redirect to="/login_page" />;
};

export default Protected;
