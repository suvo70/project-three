import React from "react";

const ProductCategory = () => {
  return (
    <div>
      <h1>This is product Category page</h1>
    </div>
  );
};

export default ProductCategory;
