import React from "react";

const ProductSubCategory = () => {
  return <div></div>;
};

export default ProductSubCategory;
